<form  action='buscar_rica2.php' method="post">

<input name="tabla" value="tabla"/>
<input name="rubro" value="rubro" type="text"  />
<input name="credito" value="cta_credito" type="text" />
<input name="debito" value="cta_debito" type="text" />
<input name="favor" value="cta_afavor" type="text" />
<input type="submit" name="enviar" />
</form>
