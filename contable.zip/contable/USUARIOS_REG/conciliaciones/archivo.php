<?php
echo "este es el archivo";
?>