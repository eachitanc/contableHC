<table width="98%" border="0" class="menuver" align="left">
  <tr>
    <td  height="32" align="center" class="a1">SUPERADMIN</td>
  </tr>
  <tr bgcolor="#E8EEFA" onmouseover="activaMenu(id);" onmouseout="quitaMenu(id)" id="m1">
    <td  class="a2" onClick="cargaArchivo('admin/sadmin/productos/reporte.php','columna1');" >&nbsp;<li class="fa fa-money"></li>&nbsp;Administrar productos</td>
  </tr>
    <tr bgcolor="#E8EEFA" onmouseover="activaMenu(id);" onmouseout="quitaMenu(id)" id="m3">
    <td class="a2">&nbsp;<li class="fa fa-suitcase"></li>&nbsp;Administrar vigencias</td>
  </tr>
    <tr bgcolor="#E8EEFA" onmouseover="activaMenu(id);" onmouseout="quitaMenu(id)" id="m2">
    <td  class="a2" onClick="cargaArchivo('admin/tablas/reporte_genera.php?campo=paquete','columna1');" >&nbsp;<li class="fa fa-money"></li>&nbsp;Configuraci&oacute;n de m&oacute;dulos</td>
  </tr>
  <tr bgcolor="#E8EEFA" onmouseover="activaMenu(id);" onmouseout="quitaMenu(id)" id="m4">
    <td class="a2">&nbsp;<li class="fa fa-suitcase"></li>&nbsp;Gesti&oacute;n administradores</td>
  </tr>
 </table>
