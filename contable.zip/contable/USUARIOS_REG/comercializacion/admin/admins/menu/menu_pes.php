
<ul class="tabs group">
       <li><a href='#' onclick=ocultaMenu()>&nbsp;<i style="color:#999" class='fa fa-reorder'></i></a>
</ul>
