<table width="98%" border="0" class="menuver" align="left">
  <tr>
    <td  height="32" align="center" class="a1">GESTION FARMACIA</td>
  </tr>
  <tr bgcolor="#E8EEFA" onmouseover="activaMenu(id);" onmouseout="quitaMenu(id)" id="m1" onclick="marcaMenu(id)">
    <td valign="top"   class="a2" onClick="cargaArchivo('admin/pedidos/inicio.php','columna1');" >&nbsp;<i class="fa fa-briefcase" style="font-size:22px"></i>&nbsp;&nbsp;Pedidos</td>
  </tr>
  <tr bgcolor="#E8EEFA" onmouseover="activaMenu(id);" onmouseout="quitaMenu(id)" id="m2" onclick="marcaMenu(id)">
    <td  class="a2" onClick="cargaArchivo('admin/recepcion/inicio.php','columna1');" >&nbsp;<li class="fa fa-check-square-o" style="font-size:22px"></li>&nbsp;&nbsp;Recepci&oacute;n</td>
  </tr>
  <tr bgcolor="#E8EEFA" onmouseover="activaMenu(id);" onmouseout="quitaMenu(id)" id="m3" onclick="marcaMenu(id)">
    <td class="a2" onClick="cargaArchivo('admin/administra/inicio.php','columna1');">&nbsp;<li class="fa fa-table" style="font-size:22px"></li>&nbsp;&nbsp;Administraci&oacute;n</td>
  </tr>
  <tr bgcolor="#E8EEFA" onmouseover="activaMenu(id);" onmouseout="quitaMenu(id)" id="m4" onclick="marcaMenu(id)">
    <td class="a2"  onClick="cargaArchivo('admin/distribucion/inicio.php','columna1');">&nbsp;<li class="fa fa-hospital-o" style="font-size:22px"></li>&nbsp;&nbsp;Distribuci&oacute;n</td>
  </tr>
   <tr bgcolor="#E8EEFA" onmouseover="activaMenu(id);" onmouseout="quitaMenu(id)" id="m5" onclick="marcaMenu(id)">
    <td class="a2"  onClick="cargaArchivo('admin/dispensar/inicio.php','columna1');">&nbsp;<li class="fa fa-user-md" style="font-size:22px"></li>&nbsp;&nbsp;Dispensaci&oacute;n</td>
  </tr>
 </table>
<input name="control1" id="control1" type="hidden" size="15" />
<input name="control2" id="control2" type="hidden" size="5" value="5" />