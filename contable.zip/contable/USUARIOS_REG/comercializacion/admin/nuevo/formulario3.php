
 <table width="90%" border="0" class="punteado" cellpadding='0' cellspacing='0' align="center">  
     <tr>  
         <td width="15%" bgcolor="#F5F5F5">Buscar:</td>
         <td width="85%" bgcolor="#F5F5F5" >
        <a href="#" id="A" onClick="cargaArchivo('admin/nuevo/reporte2.php?id=A','reportes');">A</a>&nbsp;
        <a href="#" id="B" onClick="cargaArchivo('admin/nuevo/reporte2.php?id=B','reportes');">B</a>&nbsp;
        <a href="#" id="C" onClick="cargaArchivo('admin/nuevo/reporte2.php?id=C','reportes');">C</a>&nbsp;
        <a href="#" id="D" onClick="cargaArchivo('admin/nuevo/reporte2.php?id=D','reportes');">D</a>&nbsp;
        <a href="#" id="E" onClick="cargaArchivo('admin/nuevo/reporte2.php?id=E','reportes');">E</a>&nbsp;
        <a href="#" id="F" onClick="cargaArchivo('admin/nuevo/reporte2.php?id=F','reportes');">F</a>&nbsp;
        <a href="#" id="G" onClick="cargaArchivo('admin/nuevo/reporte2.php?id=G','reportes');">G</a>&nbsp;
        <a href="#" id="H" onClick="cargaArchivo('admin/nuevo/reporte2.php?id=H','reportes');">H</a>&nbsp;
        <a href="#" id="I" onClick="cargaArchivo('admin/nuevo/reporte2.php?id=I','reportes');">I</a>&nbsp;
        <a href="#" id="J" onClick="cargaArchivo('admin/nuevo/reporte2.php?id=J','reportes');">J</a>&nbsp;
        <a href="#" id="K" onClick="cargaArchivo('admin/nuevo/reporte2.php?id=K','reportes');">K</a>&nbsp;
        <a href="#" id="L" onClick="cargaArchivo('admin/nuevo/reporte2.php?id=L','reportes');">L</a>&nbsp;
        <a href="#" id="M" onClick="cargaArchivo('admin/nuevo/reporte2.php?id=M','reportes');">M</a>&nbsp;
        <a href="#" id="N" onClick="cargaArchivo('admin/nuevo/reporte2.php?id=N','reportes');">N</a>&nbsp;
        <a href="#" id="O" onClick="cargaArchivo('admin/nuevo/reporte2.php?id=O','reportes');">O</a>&nbsp;
        <a href="#" id="P" onClick="cargaArchivo('admin/nuevo/reporte2.php?id=P','reportes');">P</a>&nbsp;
        <a href="#" id="Q" onClick="cargaArchivo('admin/nuevo/reporte2.php?id=Q','reportes');">Q</a>&nbsp;
        <a href="#" id="R" onClick="cargaArchivo('admin/nuevo/reporte2.php?id=R','reportes');">R</a>&nbsp;
        <a href="#" id="S" onClick="cargaArchivo('admin/nuevo/reporte2.php?id=S','reportes');">S</a>&nbsp;
        <a href="#" id="T" onClick="cargaArchivo('admin/nuevo/reporte2.php?id=T','reportes');">T</a>&nbsp;
        <a href="#" id="U" onClick="cargaArchivo('admin/nuevo/reporte2.php?id=U','reportes');">U</a>&nbsp;
        <a href="#" id="V" onClick="cargaArchivo('admin/nuevo/reporte2.php?id=V','reportes');">V</a>&nbsp;
        <a href="#" id="W" onClick="cargaArchivo('admin/nuevo/reporte2.php?id=W','reportes');">W</a>&nbsp;
        <a href="#" id="X" onClick="cargaArchivo('admin/nuevo/reporte2.php?id=X','reportes');">X</a>&nbsp;
        <a href="#" id="Y" onClick="cargaArchivo('admin/nuevo/reporte2.php?id=Y','reportes');">Y</a>&nbsp;
        <a href="#" id="Z" onClick="cargaArchivo('admin/nuevo/reporte2.php?id=Z','reportes');">Z</a>&nbsp;
						</td>
     </tr>
    
 </table>
 
</form> 
  </div>
    
