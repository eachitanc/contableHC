<table width="98%" border="0" class="menuver" align="left">
  <tr>
    <td  height="50" align="center" class="a1">2. TESORERIA / INFORMES</td>
  </tr>
  <tr bgcolor="#E8EEFA" onmouseover="activaMenu(id);" onmouseout="quitaMenu(id)" id="1">
    <td  class="a2">&nbsp;<li class="fa fa-money"></li>&nbsp;Ejecuciones de PAC</td>
  </tr>
  <tr bgcolor="#E8EEFA" onmouseover="activaMenu(id);" onmouseout="quitaMenu(id)" id="2">
    <td class="a2">&nbsp;<li class="fa fa-suitcase"></li>&nbsp;Informacion detallada</td>
  </tr>
  <tr bgcolor="#E8EEFA" onmouseover="activaMenu(id);" onmouseout="quitaMenu(id)" id="3">
    <td class="a2">&nbsp;<li class="fa fa-minus-circle"></li>&nbsp;Retencion en la fuente</td>
  </tr>
  <tr bgcolor="#E8EEFA" onmouseover="activaMenu(id);" onmouseout="quitaMenu(id)" id="4">
    <td class="a2">&nbsp;<li class="fa fa-money"></li>&nbsp;Movimientos de tesoreria</td>
  </tr>
  <tr bgcolor="#E8EEFA" onmouseover="activaMenu(id);" onmouseout="quitaMenu(id)" id="5">
    <td class="a2">&nbsp;<li class="fa fa-check"></li>&nbsp;Entes de control (+10) &nbsp;<li class="fa fa-angle-double-right"></li> </td>
  </tr>
  <tr>
    <td  align="left" class="a2" ><a href="#" onClick="cargaArchivo('user/flujo/menu_conf.php','izquierda');">1. CONFIGURACIONES</a></td>
  </tr>
  <tr>
    <td  align="left" class="a2" ><a href="#" onClick="cargaArchivo('user/flujo/menu_ver.php','izquierda');">2. GESTION</a></td>
  </tr>
  <tr>
    <td  align="center" height="45" ><a href="#" onClick="cargaArchivo('user/flujo/menu.php','contenido');">VOLVER</a></td>
  </tr>


</table>
